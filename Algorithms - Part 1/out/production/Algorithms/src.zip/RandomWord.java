import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {

    public static void main(String[] args) {
        String champion = null;
        while (!StdIn.isEmpty()) {
            String input = StdIn.readString();
            if (input != null && !input.isEmpty() && StdRandom.bernoulli(0.2)) {
                champion = input;
            }
        }
        StdOut.println(champion);
    }
}
